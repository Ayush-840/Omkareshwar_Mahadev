# Changelog

All notable changes are documented here. Format follows Keep a Changelog; versions follow Semantic Versioning.

## [Unreleased]

### Added
- Project documentation set (PRD, TRD, design, UI spec, data model, security, roadmap, testing, release guide).

## [1.0.0] - planned

### Added
- Home screen with hero banner and 3 x 3 tile grid
- Temple Info, Aarti Darshan, Events, Photo Gallery, Notices, Videos, Contact
- Donation information screen linking to the temple's web page
- Devotee Community v1: committee list, volunteer form, WhatsApp link
- Hindi / English language switch
- Push notifications and local aarti reminders
- Offline reading and offline aarti audio
- Admin area for notices, events and photos

## [1.1.0] - planned

### Added
- Tithi / panchang and festival countdown on home
- Audio player improvements
- Calendar and WhatsApp share polish
